// stdafx.cpp : Quelltextdatei, die nur die Standard-Includes einbindet
//  LinkCreator.pch ist der vorcompilierte Header
//  stdafx.obj enth�lt die vorcompilierte Typinformation

#include "stdafx.h"


