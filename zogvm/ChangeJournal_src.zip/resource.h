//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ChangeJournal.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CHANGEJOURNAL_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDD_DLG_FILTER                  129
#define IDR_MENU1                       132
#define IDC_LIST                        1001
#define IDC_CMB_DRIVE                   1002
#define IDC_DETAIL                      1003
#define IDC_BTN_FILTER                  1004
#define IDC_CK_BASIC_INFO_CHANGE        1005
#define IDC_QUERY                       1005
#define IDC_CK_CLOSE                    1006
#define IDC_BTN_FIRST_PAGE              1006
#define IDC_CK_COMPRESSION_CHANGE       1007
#define IDC_CMB_BLOCK                   1007
#define IDC_CK_DATA_EXTEND              1008
#define IDC_CK_DATA_OVERWRITE           1009
#define IDC_BTN_QUERY                   1009
#define IDC_CK_DATA_TRUNCATION          1010
#define IDC_BTN_NEXT_PAGE               1010
#define IDC_CK_EA_CHANGE                1011
#define IDC_PAGE                        1011
#define IDC_CK_ENCRYPTION_CHANGE        1012
#define IDC_CK_FILE_CREATE              1013
#define IDC_CK_FILE_DELETE              1014
#define IDC_CK_HARD_LINK_CHANGE         1015
#define IDC_CK_INDEXABLE_CHANGE         1016
#define IDC_CK_NAMED_DATA_EXTEND        1017
#define IDC_CK_NAMED_DATA_OVERWRITE     1018
#define IDC_CK_NAMED_DATA_TRUNCATION    1019
#define IDC_CK_OBJECT_ID_CHANGE         1020
#define IDC_CK_RENAME_NEW_NAME          1021
#define IDC_CK_RENAME_OLD_NAME          1022
#define IDC_CK_REPARSE_POINT_CHANGE     1023
#define IDC_CK_SECURITY_CHANGE          1025
#define IDC_CK_STREAM_CHANGE            1026
#define IDM_CREATE                      32771
#define IDM_DISABLE                     32772
#define IDM_EXIT                        32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
