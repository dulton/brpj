//
//  formulas.h
//  xlsLibTester
//
//  Created by David Hoerl on 1/7/14.
//
//

#ifndef __xlsLibTester__formulas__
#define __xlsLibTester__formulas__

#include <iostream>

void formulas(void);

#endif /* defined(__xlsLibTester__formulas__) */
