#!/bin/sh

./testC /Volumes/Data/svn/xlslib/xlslib/targets/test
./testCPP /Volumes/Data/svn/xlslib/xlslib/targets/test
./PR2859188 /Volumes/Data/svn/xlslib/xlslib/targets/test
./PR3076678 /Volumes/Data/svn/xlslib/xlslib/targets/test




