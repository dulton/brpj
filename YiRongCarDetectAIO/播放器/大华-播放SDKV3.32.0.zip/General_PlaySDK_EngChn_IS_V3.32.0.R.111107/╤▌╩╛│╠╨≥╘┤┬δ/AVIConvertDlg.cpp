// AVIConvertDlg.cpp : implementation file
//

#include "stdafx.h"
#include "player264demo.h"
#include "AVIConvertDlg.h"
#include "dhplay.h"
#include "multilanguage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#define AVICONV_PORT		450

/////////////////////////////////////////////////////////////////////////////
DWORD WINAPI AVIConvert_Proc(LPVOID pParam)
{
	CAVIConvertDlg* pThis = (CAVIConvertDlg*)pParam;
	
	pThis->AVIConv_Thread();
	
	return 0;
}

void CALLBACK AVIConvertCBFunc(long nPort, long lMediaChangeType, long lUser, BOOL *pbIfContinue, char *sNewFileName)
{
	CAVIConvertDlg *pThis = (CAVIConvertDlg *)lUser;

	switch (lMediaChangeType)
	{
	case AVI_MEDIACHANGE_FRAMERATE:
	case AVI_MEDIACHANGE_RESOLUTION:
		{
			CString csNewFileName, csTemp;
			*pbIfContinue = TRUE;
			int iPos = pThis->m_csTargetFile.Find(".avi");
			csNewFileName = pThis->m_csTargetFile.Mid(0, iPos);
			csTemp.Format("_%d.avi", pThis->m_iChangeCount);
			csNewFileName += csTemp;
			memcpy(sNewFileName, csNewFileName.GetBuffer(0), csNewFileName.GetLength());
			pThis->m_iChangeCount++;
		}
		break;
	default:
		break;
	}
}
/////////////////////////////////////////////////////////////////////////////
// CAVIConvertDlg dialog


CAVIConvertDlg::CAVIConvertDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAVIConvertDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAVIConvertDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_convertMode = INVALID_CONVERT;
}


void CAVIConvertDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAVIConvertDlg)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAVIConvertDlg, CDialog)
	//{{AFX_MSG_MAP(CAVIConvertDlg)
	ON_BN_CLICKED(IDC_BUTTON_SRCFILE, OnButtonSrcfile)
	ON_BN_CLICKED(IDC_BUTTON_TARGFILE, OnButtonTargfile)
	ON_BN_CLICKED(IDC_BUTTON_CONVERT, OnButtonConvert)
	ON_WM_CLOSE()
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAVIConvertDlg message handlers
BOOL CAVIConvertDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_csSourceFile = "";
	m_csTargetFile = "";
	m_iChangeCount = 0;
	m_bAVIConvEnable = FALSE;

	if (m_convertMode == AVI_CONVERT)
	{
		SetWindowText("AVI Convert");
	}
	else if (m_convertMode == ASF_CONVERT)
	{
		SetWindowText("ASF Convert");
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CAVIConvertDlg::OnButtonSrcfile() 
{
	CFileDialog FileChooser(TRUE, 
		NULL,
		NULL, 
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"All files(*.*)|*.*||");
	//choose file
	if (FileChooser.DoModal()==IDOK)
	{
		m_csSourceFile = FileChooser.GetPathName() ;
	}
	GetDlgItem(IDC_EDIT_SRCFILE)->SetWindowText(m_csSourceFile);

	int iPos = m_csSourceFile.Find(".dav");
	if (iPos < 0) return;
	m_csTargetFile = m_csSourceFile.Mid(0, iPos);
	if (m_convertMode == AVI_CONVERT)
		m_csTargetFile += ".avi";
	else if (m_convertMode == ASF_CONVERT)
	{
		m_csTargetFile += ".asf";
	}

	GetDlgItem(IDC_EDIT_TARGFILE)->SetWindowText(m_csTargetFile);	
}

void CAVIConvertDlg::OnButtonTargfile() 
{
	if (m_convertMode == AVI_CONVERT)
	{
		CFileDialog FileChooser(FALSE, 
			NULL,
			NULL, 
			OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
			"avi files(*.avi)|*.avi||");
		//choose file
		if (FileChooser.DoModal()==IDOK)
		{
			m_csTargetFile = FileChooser.GetPathName() ;
		}
		
		int iPos = m_csTargetFile.Find(".avi");
		if (iPos == -1)
		{
			m_csTargetFile += ".avi";
		}
	}
	else if (m_convertMode == ASF_CONVERT)
	{
		CFileDialog FileChooser(FALSE, 
			NULL,
			NULL, 
			OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
			"asf files(*.asf)|*.asf||");
		//choose file
		if (FileChooser.DoModal()==IDOK)
		{
			m_csTargetFile = FileChooser.GetPathName() ;
		}
		
		int iPos = m_csTargetFile.Find(".asf");
		if (iPos == -1)
		{
			m_csTargetFile += ".asf";
		}
	}
	GetDlgItem(IDC_EDIT_TARGFILE)->SetWindowText(m_csTargetFile);	
}

void CAVIConvertDlg::OnButtonConvert() 
{
	if (m_csSourceFile == "") return ;

	m_bAVIConvEnable = TRUE;

	DWORD dwThreadId = 0;
	HANDLE hAVIConvThread = CreateThread(NULL, 0, AVIConvert_Proc, this, 0, &dwThreadId);

	GetDlgItem(IDC_BUTTON_CONVERT)->EnableWindow(FALSE);	
}

void CAVIConvertDlg::reset()
{
	m_csSourceFile = "";
	m_csTargetFile = "";
	m_iChangeCount = 0;
	m_bAVIConvEnable = FALSE;
	SetWindowText("");
	UpdateData(TRUE);
	GetDlgItem(IDC_EDIT_TARGFILE)->SetWindowText("");
	GetDlgItem(IDC_EDIT_SRCFILE)->SetWindowText("");
	CProgressCtrl *pProgCtrl = (CProgressCtrl*)GetDlgItem(IDC_PROGRESS_CONVERT);
	pProgCtrl->SetPos(0);
	return ;
}
void CAVIConvertDlg::setConvertType(int nMode)
{
	switch(nMode)
	{
	case CAVIConvertDlg::AVI_CONVERT:
		SetWindowText("AVI Convert");
		break;
	case CAVIConvertDlg::ASF_CONVERT:
		SetWindowText("ASF Convert");
		break;
	default:
		break;
	}
	m_convertMode = nMode;
	return;
}
void CAVIConvertDlg::AVIConv_Thread()
{
	CProgressCtrl *pProgCtrl = (CProgressCtrl*)GetDlgItem(IDC_PROGRESS_CONVERT);
	pProgCtrl->SetRange(0, 1000);
	pProgCtrl->SetPos(0);
	
	PLAY_SetStreamOpenMode(AVICONV_PORT, STREAME_FILE);
	PLAY_OpenStream(AVICONV_PORT, NULL, 0, 1024 * 100);
	
	//PLAY_SetDecCallBack(AVICONV_PORT, MediaDecCBFun);
	//PLAY_SetDecCBStream(AVICONV_PORT, 3);
	
	if (!PLAY_Play(AVICONV_PORT, NULL))
	{
		PLAY_CloseStream(AVICONV_PORT);
	}

	GetDlgItem(IDC_EDIT_TARGFILE)->GetWindowText(m_csTargetFile);
	// �ص����ڴ�����֡�ʣ���ֱ��ʵ��ļ���AVIת��	
	BOOL bRet = FALSE;
	if (m_convertMode == AVI_CONVERT)
	{
		bRet = PLAY_StartAVIConvert(AVICONV_PORT, m_csTargetFile.GetBuffer(0), AVIConvertCBFunc, (long)this);
	}
	else if (m_convertMode == ASF_CONVERT)
	{
		bRet = PLAY_StartDataRecord(AVICONV_PORT, m_csTargetFile.GetBuffer(0), 2);
	}
	if (!bRet)
	{
		PLAY_Stop(AVICONV_PORT);
		PLAY_CloseStream(AVICONV_PORT);

		MessageBox(ConvertString("AVI Convert Failed!!"));
		return ;
	}
	
	CFile SourceFile;
	if ( !SourceFile.Open(m_csSourceFile, CFile::modeRead | CFile::shareDenyNone) )
	{
		PLAY_StopAVIConvert(AVICONV_PORT);
		PLAY_Stop(AVICONV_PORT);
		PLAY_CloseStream(AVICONV_PORT);
	}
	
	DWORD dwFileLen = SourceFile.GetLength();	
	
	const int BUFLEN = 8 * 1024;
	BYTE InfoBuf[BUFLEN];
	DWORD nRead;
	DWORD dwCurPos = 0;
	
	try
	{
		while (m_bAVIConvEnable)
		{
			memset(InfoBuf, 0, sizeof(InfoBuf));
			nRead = SourceFile.Read(InfoBuf, BUFLEN);
			
			if (nRead <= 0)
			{
				break;
			}
			
			dwCurPos += nRead;			
			
			while (m_bAVIConvEnable && !PLAY_InputData( AVICONV_PORT, InfoBuf, nRead))//����Ϊfalse
			{
				Sleep(5);
			}
			
			double fpress = (double)dwCurPos/(double)dwFileLen;
			
			int iProgressPos = (int)(fpress*1000.0);
			if (m_bAVIConvEnable)
				pProgCtrl->SetPos(iProgressPos);
		}
	}
	catch (CException* e)
	{
		PLAY_StopAVIConvert(AVICONV_PORT);
		PLAY_Stop(AVICONV_PORT);
		PLAY_CloseStream(AVICONV_PORT);
		SourceFile.Close();
		e->Delete();
	}
	
	while (m_bAVIConvEnable && !(PLAY_GetSourceBufferRemain(AVICONV_PORT) == 0))
	{
		//��������� number=0ʱ��������������ݶ�����ʾ��ص���ȫ
		//number < numʱ������������
		while (m_bAVIConvEnable && PLAY_GetSourceBufferRemain(AVICONV_PORT) > 0)
		{
			if (PLAY_GetBufferValue(AVICONV_PORT, BUF_VIDEO_RENDER) < 1) 
			{
				//�����������ز���
				Sleep(5);
				break;
			}
			else
			{
				Sleep(10);
			}
		}
	}
	
	pProgCtrl->SetPos(1000);
	if (m_convertMode == AVI_CONVERT)
	{
		PLAY_StopAVIConvert(AVICONV_PORT);
	}
	else if (m_convertMode == ASF_CONVERT)
	{
		PLAY_StopDataRecord(AVICONV_PORT);
	}
	PLAY_Stop(AVICONV_PORT);
	PLAY_CloseStream(AVICONV_PORT);
	SourceFile.Close();
	
	if (m_bAVIConvEnable)
	{
		if (m_convertMode == AVI_CONVERT)
			MessageBox(ConvertString("AVI convert complete!!"));
		else if (m_convertMode == ASF_CONVERT)
			MessageBox(ConvertString("ASF convert complete!!"));
		
		m_bAVIConvEnable = FALSE;		
	}
	pProgCtrl->SetPos(0);
	GetDlgItem(IDC_BUTTON_CONVERT)->EnableWindow(TRUE);
}

void CAVIConvertDlg::OnCancel() 
{
	if (m_bAVIConvEnable)
	{
		m_bAVIConvEnable = FALSE;
		GetDlgItem(IDC_BUTTON_CONVERT)->EnableWindow(TRUE);
		return ;
	}
	
	CDialog::OnCancel();
}

void CAVIConvertDlg::OnClose() 
{
	if (m_bAVIConvEnable)
	{
		m_bAVIConvEnable = FALSE;
	}
	
	CDialog::OnClose();
}

void CAVIConvertDlg::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	// TODO: Add your message handler code here
	SetWndStaticText(this);
}
