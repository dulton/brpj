/* dirent.h - stub header file for MS VC compiler */
#ifndef DIRENT_STUB_H
#define DIRENT_STUB_H

#endif /* DIRENT_STUB_H */
