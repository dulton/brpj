/* unistd.h stub for windows platform */
#ifndef UNISTD_H
#define UNISTD_H

#include "platform-dependent.h"

#endif /* UNISTD_H */
